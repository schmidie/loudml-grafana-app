import { ConfigCtrl } from './config/config_ctrl'

export { ConfigCtrl };
