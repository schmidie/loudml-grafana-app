declare module '*.html' {
  const contents: string
  export = contents
}